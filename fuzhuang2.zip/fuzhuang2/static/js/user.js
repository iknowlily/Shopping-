$(function() {
  // 页面加载时更新小计和总价
  updateSubtotal();
  updateTotal();

  // 数量增加事件处理
  $('.num .add').click(function() {
    var $input = $(this).siblings('input');
    var count = parseFloat($input.val());
    count++;
    $input.val(count);
    updateSubtotal();
    updateTotal();
  });

  // 数量减少事件处理
  $('.num .reduc').click(function() {
    var $input = $(this).siblings('input');
    var count = parseFloat($input.val());
    if (count > 1) {
      count--;
      $input.val(count);
      updateSubtotal();
      updateTotal();
    }
  });

  // 删除当前行
  $('.del').click(function() {
    $(this).closest('.imfor').remove();
    updateTotal();
  });

  // 更新小计
  function updateSubtotal() {
    $('.imfor').each(function() {
      var count = parseFloat($(this).find('.num input').val());
      var price = parseFloat($(this).find('.pices').text());
      var subtotal = count * price;
      $(this).find('.totle').text(subtotal.toFixed(2));
    });
  }

  // 更新总价
  function updateTotal() {
    var total = 0;
    $('.imfor').each(function() {
      var subtotal = parseFloat($(this).find('.totle').text());
      total += subtotal;
    });
    $('#susum').text(total.toFixed(2));
  }
});
