from flask import Flask, current_app
from blueprint.views import register_blueprint


def create_app():
    app = Flask("fuzhuang2")
    register_blueprint(app)
    return app
